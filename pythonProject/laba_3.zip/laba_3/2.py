phrase = "Hello World"

for letter in reversed(phrase):
    print(letter)