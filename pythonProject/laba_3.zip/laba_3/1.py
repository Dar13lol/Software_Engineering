result = 1

for _ in range(6):
    result += 5

print(result)